PakFreeTools — 10 New Tools Add-on

1) Copy these 10 folders into the ROOT of your existing GitHub Pages repository.
2) Do NOT replace your existing index.html or existing tool folders.
3) Add the cards from homepage-tools-snippet.html inside the EXISTING homepage tools grid.
4) Add the <url> blocks from sitemap-additions.txt inside the existing sitemap.xml <urlset>.
5) Do NOT change robots.txt.

New URLs:
/jpg-to-png/
/png-to-jpg/
/jpg-to-pdf/
/pdf-to-jpg/
/word-to-pdf/
/pdf-to-word/
/word-to-excel/
/urdu-typing-test/
/english-typing-test/
/unit-converter/

Important conversion limitations:
- PDF to Word extracts selectable text into DOCX; scanned/image-only PDFs need OCR and are not falsely presented as supported.
- Word to PDF supports standard DOCX content and may not reproduce complex Word layouts exactly.
- Word to Excel extracts detected tables from DOCX into separate XLSX sheets.

No login, signup, backend, paid API, or file upload service is used.
